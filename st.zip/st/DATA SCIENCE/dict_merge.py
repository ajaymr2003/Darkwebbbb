l={'name':'linto','age':23,'city':'kollam'}
m={'city':'kollam'}
print(l)
print(m)
print("Merged dictionary")
d=l | m
print(d)