l=(('b',4),('a',5))
d=dict(l)
print(d)