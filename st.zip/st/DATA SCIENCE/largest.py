l=[5,6,7,18,12,9]
m=l[0]
for i in l:
    if i > m:
        m = i
print("Largest number is:", m)

l=[5,6,7,29,12,9]
gr=max(l)

print("Largest number using max function:", gr)